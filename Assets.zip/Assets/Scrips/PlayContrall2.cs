using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayContrall2 : MonoBehaviour
{
    // Start is called before the first frame update
    public float speed;
    public float turnSpeed = 45;
    public float hori;
    public float forwardInput;
    public Camera mainCamera;
    public Camera camera1;
    
    void Start()
    {
        mainCamera.enabled = true;
        camera1.enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
        
        hori = Input.GetAxis("Horizontal2");
        forwardInput = Input.GetAxis("Vertical2");
        transform.Rotate(Vector3.up, turnSpeed * Time.deltaTime * hori);
        this.transform.Translate(Vector3.forward * speed * Time.deltaTime * forwardInput);
        if (Input.GetKeyDown(KeyCode.K))
        {
            mainCamera.enabled = !mainCamera.enabled;
            camera1.enabled = !camera1.enabled;
        }

    }
}
