using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerConroll : MonoBehaviour
{
    public float speed;
    public float turnSpeed = 45;
    public float hori;
    public float forwardInput;
    public Camera mainCamera;
    public Camera camera1;
   // public KeyCode getKey;//�Զ����
    // Start is called before the first frame update
    void Start()
    {
        mainCamera.enabled = true;
        camera1.enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
        hori = Input.GetAxis("Horizontal");
        forwardInput = Input.GetAxis("Vertical");
        


        //transform.Translate(0, 0, 1);
        // transform.Translate(Vector3.forward);
        //this.transform.Translate(new Vector3(0,0,1));

        //transform.Translate(Vector3.right * Time.deltaTime * turnSpeed*hori);
        transform.Rotate(Vector3.up,turnSpeed* Time.deltaTime*hori);
        this.transform.Translate(Vector3.forward*speed*Time.deltaTime*forwardInput);
        if(Input.GetKeyDown(KeyCode.J))
        {
            mainCamera.enabled = !mainCamera.enabled;
            camera1.enabled = !camera1.enabled;
        }
        


    }
}
